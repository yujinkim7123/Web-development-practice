#include<stdio.h>
#include "a.h"

void run()
{

	printf("run.c");
	a();

}
