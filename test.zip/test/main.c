#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main()
{
	char str[100];
	char var[100][10];
	char varnum[100][5];
	int index = 0;

	while(1)
	{
	
		printf("yujin.kim >> ");
		fgets(str, 100, stdin);
		if(strcmp(str, "\n")==0)
		{
//			printf("\n");
			continue;
		
		}
		char *string = strtok(str, "\n");
		char *line = strtok(string, " ");
	//	printf("%c\n", string[5]);
		
	    if(strcmp(line, "shoot")==0)
		{
			int number = string[6] -'0';

			for(int i = number; i >= 1; i--)
			{
				printf("%d ", i);
			}
			printf("\n");
		
		}
		else if(strcmp(line, "show") == 0)
		{
		//	printf("%d", index);
		//	printf("%s %s", var[0], varnum[0]);
			for(int i =0 ; i < index; i++)
			{
			
				printf("%s %s \n", var[i], varnum[i]);
			
			
			}
		
		}
		else if(strcmp(line, "echo")==0)
		{
		
	//		printf("%s", string);
			char echovar[10];
			int ch = 0;
			for(int i = 5; i < 10; i++)
			{
				if(str[i] == '\n')
					break;
				echovar[ch++] = string[i];
	//			printf("%c", string[i]);
			
			}
			echovar[ch] ='\0';
	//		printf("%s\n", echovar);

			int avl = 0;
			for(int i =0; i < index; i++)
			{
				if(strcmp(var[i], echovar)==0)
				{
					
					printf("%s \n", varnum[i]);
					avl = 1;

				}
			}


			if(avl == 0)
			{
			
				printf("[ERROR]Wrong Variable\n");
			
			}
		
		
		}
		else{
		
			int check = 0;
			int numindex = 0;
			int varindex = 0;
			for(int i = 0; i < strlen(string); i++)
			{
				
				if(check == 1)
				{
				
					varnum[index][numindex++] = string[i];
				}
				else
				{
					if(string[i] != '=')
						var[index][varindex++] = string[i];
				
				}
				if(string[i] == '=')
					check = 1;
			
			}
			var[index][varindex] = '\0';
			varnum[index][numindex] = '\0';
		//	printf("%s %s \n", var[index], varnum[index]);
			index++;
		//	printf("%d", index);	
		}
		
	
	}	


}
