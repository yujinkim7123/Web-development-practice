#include<iostream>

using namespace std;



int main(int argc, char** argv)
{
	int test_case;
	int T;
	cin >> T;

	for (test_case = 1; test_case <= T; ++test_case)
	{
		int N, K;
		int map[15][15] = { 0, };
		cin >> N >> K;


		for (int i = 0; i < N; i++)
		{
			for (int j = 0; j < N; j++)
			{
				cin >> map[i][j];
			}
		}

		int answer = 0;

		for (int i = 0; i < N; i++)
		{
			for (int j = 0; j < N; j++)
			{
				int k = j;

				if (map[i][j] == 1)
				{
					int cnt = 0;
					while (1)
					{
						if (map[i][k] == 1)
							cnt++;
						if (map[i][k] == 0 || k == N - 1)
							break;

						k++;
					}

					if (cnt == K) {

						//cout << i << k << "\n";
						answer++;

					}

					j = k;
				}
			}
		}

		for (int i = 0; i < N; i++)
		{
			for (int j = 0; j < N; j++)
			{
				int k = j;

				if (map[j][i] == 1)
				{
					int cnt = 0;
					while (1)
					{
						if (map[k][i] == 1)
							cnt++;
						if (map[k][i] == 0 || k == N - 1)
							break;

						k++;
					}
					if (cnt == K) {

						//cout << k << i << "\n";
						answer++;

					}

					j = k;
				}
			}
		}

		cout << "#" << test_case << " " << answer << "\n";
	}
	return 0;//��������� �ݵ�� 0�� �����ؾ��մϴ�.
}