#include<iostream>
using namespace std;

int main(int argc, char** argv)
{
	int test_case;
	int T;

	cin >> T;
	
	for (test_case = 1; test_case <= T; ++test_case)
	{

		int n, m;

		int a[20];
		int b[20];

		cin >> n >> m;

		for (int i = 0; i < n; i++)
		{
			cin >> a[i];
		}

		for (int j = 0; j < m; j++)
		{
			cin >> b[j];
		}


		int answer = 0;

		if (n > m)
		{
			int con = n - m;

			for (int i = 0; i <= con; i++) {

				int Sum = 0;

				for (int j = i; j < m + i; j++) {
					Sum = Sum + (b[j - i] * a[j]);
					//	cout << (b[j - i] * a[j]) << " ";
				}

				if (answer < Sum)
					answer = Sum;
			}

		}
		else
		{
			int con = m - n;

			for (int i = 0; i <= con; i++) {
				int Sum = 0;
				for (int j = i; j < n + i; j++)
					Sum = Sum + (b[j] * a[j - i]);

				if (answer < Sum)
					answer = Sum;
			}
		}

		cout << "#" << test_case << " " << answer << "\n";

	}
	return 0;//��������� �ݵ�� 0�� �����ؾ��մϴ�.
}