#include<iostream>

using namespace std;

int main(int argc, char** argv)
{
	int test_case;
	int T;

	cin >> T;

	for (test_case = 1; test_case <= T; ++test_case)
	{

		int map[16][16] = { 0, };
		long answer = 0;

		int N;
		int M;
		cin >> N >> M;

		for (int i = 0; i < N; i++)
		{
			for (int j = 0; j < N; j++) {
				cin >> map[i][j];
			}
		}


		for (int i = 0; i < N - M + 1; i++)
		{
			for (int j = 0; j < N - M + 1; j++) {

				long sum = 0;

				for (int k = 0; k < M; k++) {

					for (int h = 0; h < M; h++) {

						sum += map[i + k][j + h];

					}

				}

				if (answer < sum)
					answer = sum;

			}

		}


		cout << "#" << test_case << " " << answer << "\n";

	}
	return 0;//��������� �ݵ�� 0�� �����ؾ��մϴ�.
}