#include<iostream>

using namespace std;

int map[7][7] = { 0, };
int cmap[7][29] = { 0, };
int N;

void print()
{
	for (int i = 0; i < N; i++) {
		for (int j = 1; j <= N * 3; j++)
		{
			cout << cmap[i][j];
			if (j % N == 0)
				cout << " ";


		}
		cout << "\n";

	}
}

void print2()
{
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < N; j++)
		{
			cout << map[i][j];

		}
		cout << "\n";

	}
}

void rotae(int x, int y, int n)
{

	int startx = x;
	int endx = x + n;
	int starty = y;
	int endy = y + n;

	//cout << x << y << n << "\n";


	int copy[7] = { 0, };
	int k = 0;

	for (int i = starty; i < endy; i++) copy[k++] = map[i][startx];

	int cy = starty;

	for (int i = startx; i < endx; i++, cy++) map[cy][startx] = map[endy][i];
	//print2();
	//cout << x << y << n << "\n";
	int cx = startx;

	for (int i = endy; i > starty; i--) map[endy][cx++] = map[i][endx];
	//print2();
//	cout << x << y << n << "\n";
	cy = endy;

	for (int i = endx; i > startx; i--) map[cy--][endx] = map[starty][i];
	//	print2();
		//cout << x << y << n << "\n";

	k = 0;
	for (int i = endx; i > startx; i--) map[starty][i] = copy[k++];
	//	print2();
	//	cout << x << y << n << "\n";
}



int main(int argc, char** argv)
{
	int test_case;
	int T;
	
	cin >> T;
	
	for (test_case = 1; test_case <= T; ++test_case)
	{


		cin >> N;

		for (int i = 0; i < N; i++)
		{
			for (int j = 0; j < N; j++)
			{
				cin >> map[i][j];
			}
		}

		cout << "#" << test_case << "\n";

		int count = 1;

		for (int i = 0; i < 3; i++)
		{

			int n = N;
			for (int j = 0; j < N / 2; j++)
			{

				rotae(j, j, n - 1);

				n = n - 2;

			}
			for (int k = 0; k < N; k++)
			{
				for (int j = 0; j < N; j++)
				{
					cmap[k][count + j] = map[k][j];

				}
			}

			count = count + N;

		}

		print();

	}
	return 0;//��������� �ݵ�� 0�� �����ؾ��մϴ�.
}