#include<iostream>

using namespace std;

int main(int argc, char** argv)
{
	int test_case;
	int T;

	cin >> T;

	for (test_case = 1; test_case <= T; ++test_case)
	{
		int row[10][10] = { 0, };
		int high[10][10] = { 0, };
		int box[10][10] = { 0, };
		int map[9][9];
		bool check = true;

		for (int i = 0; i < 9; i++)
		{
			for (int j = 0; j < 9; j++)
			{
				cin >> map[i][j];

				row[i][map[i][j]]++;
				high[j][map[i][j]]++;

				if (row[i][map[i][j]] > 1)
					check = false;
				if (high[j][map[i][j]] > 1)
					check = false;

			}
		}

		if (check)
		{
			int g = 0;
			for (int h = 0; h < 9; h = h + 3) {

				for (int i = 0; i < 9; i = i + 3)
				{
					for (int j = 0; j < 3; j++)
					{
						for (int k = 0; k < 3; k++)
						{
							box[g][map[h + j][i + k]]++;
							if (box[i][map[h][i]] > 1)
							{
								check = false;
								break;
							}
						}

						if (check == false)
							break;

					}
					if (check == false)
						break;
					g++;
					//cout << h << i << "\n";
				}
				if (check == false)
					break;



			}

		}

		if (check)
			cout << "#" << test_case << " " << 1 << "\n";
		else
			cout << "#" << test_case << " " << 0 << "\n";
	}
	return 0;//��������� �ݵ�� 0�� �����ؾ��մϴ�.
}