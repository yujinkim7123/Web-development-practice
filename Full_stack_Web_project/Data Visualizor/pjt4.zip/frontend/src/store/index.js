import Vue from 'vue'
import Vuex from 'vuex'
import { dataLap } from "../utils/axios"

Vue.use(Vuex)

const makeColor = () => {
  return "#" + Math.round(Math.random() * 0xffffff).toString(16)
}

export default new Vuex.Store({
  state: {
    chartData : ""
  },
  getters: {
  },
  mutations: {
    CHANGE_CHART_DATA(state,data){
      state.chartData = data
    }
  },
  actions: {
    async generateChartData({commit}){
      const result = await dataLap.get()
      console.log(result.data)

      const chartData = {
        labels : result.data[0].data.map(e => e.period),

        datasets: result.data.reduce((acc,cur) => {
          console.log(cur)
          let label = cur.title;
          let data = cur.data.map(e => e.ratio)
          acc.push({label, data, fill: false, backgroundColor: makeColor(), borderColor:makeColor() })
          return acc
        },[])
      }

      commit("CHANGE_CHART_DATA", chartData)
    }
  },
  modules: {
  }
})
