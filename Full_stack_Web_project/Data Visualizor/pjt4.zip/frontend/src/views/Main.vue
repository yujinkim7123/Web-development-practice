<template>
  <div class="main-container">
    <Form></Form>
    <ReactiveBarChart :chartData="chartData" v-if="chartData">
    </ReactiveBarChart>
  </div>
</template>

<script>
import ReactiveBarChart from "../components/ReactiveBarChart"
import Form from "../components/Form.vue"
import { mapState, mapActions  } from "vuex"

export default {
  components: {
    ReactiveBarChart,
    Form
  },
  data(){
    return {
      // chartData : null,
    }
  },
  // 캐싱
  computed:{
    ...mapState(["chartData"])
  },
  methods: {
    ...mapActions(["generateChartData"])
    // generateData(){
    //   // 랜덤으로 숫자를 1~10까지 고릅니다.
    //   // 그 고른숫자로 색깔 배열을 만듬
    //   // color = ["Red", "Blue"]
    //   // color[랜덤숫자]
    //   const newArray = []
    //   const Array = []

    //   for(let i = 0; i < 10; i++){
    //     const radomValue = Math.floor(Math.random()*10)
    //     newArray.push(radomValue)
    //   }

    //   for(let i = 0; i < 10; i++){
    //     const radomValue = Math.floor(Math.random()*10)
    //     Array.push(radomValue)
    //   }

    //   this.chartData = {
    //     labels: ["Red", "Blue", "Yellow", "Green", "Purple", "Orange"],
    //     datasets: [
    //       {
    //         label: "Data One",
    //         backgroundColor : "#f87979",
    //         data: newArray,
    //         fill: false
    //       },
    //       {
    //         label: "Data Two",
    //         backgroundColor : "#ffccaa",
    //         data: Array,
    //         fill: false
    //       }
    //     ]
    //   }

    // }
  },
  mounted(){
    this.generateChartData()
  }
}
</script>

<style>
.main-container{
  display: flex;
  padding:20px;
}

.main-container > * {
  width:700px;
}
</style>