<template>
  <div>
    <div @click="moveDetail(list.id)" v-for="list in lists" :key="list.id" class="list-wrapper">

      <div>{{list}}</div>

    
    </div>
  </div>
</template>

<script>
import {api} from "../../utils/axios"

export default {

  methods:{
    moveDetail(id){
    this.$router.push(`/${id}`);
    
    }
  },

  data(){
    return {
      lists: []
    }
  },

  async created(){

    this.$store.commit("SET_LOADING", true);
    const results = await api.jsonplaceholder.findAll();
    console.log(results);
    this.lists = results.data;
    this.$store.commit("SET_LOADING", false);

  }

}
</script>

<style>
.list-wrapper{
  border: 1px solid black;
  padding: 20px;
}
</style>