<template>
  
<div>

 <router-view/>
 <div v-if="$store.state.loading" class="spinner">
 <b-spinner variant="primary" label="Spinning"></b-spinner>
</div>

</div>


</template>

<script>
export default {

  data(){

    return{
      myName: "" 
    }

  }

}
</script>

<style>
.spinner{
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -40%);
}
</style>